# ReadQuest — Library Book Recommendation System

ReadQuest is a simple, mobile-friendly Python web application that helps readers discover books based on their interests.

## Main features
- Search by book title or author
- Filter by genre, mood and reading level
- See the highest-rated matching books first
- Browse a curated sample collection
- Separate About page

## Technology used
Python, Flask, HTML and CSS.

## How recommendations work
The app filters the sample book collection using the reader's selected options. Matching books are then sorted by their sample rating. This is a beginner-friendly rule-based recommendation method; it does not use machine learning.

## Run locally
1. Install Python.
2. Open a terminal in this folder.
3. Run `pip install -r requirements.txt`.
4. Run `python app.py`.
5. Open `http://127.0.0.1:5000` in a browser.

## Project structure
- `app.py` — Python and Flask application
- `templates/` — HTML pages
- `static/style.css` — website design
- `requirements.txt` — Python dependency

Book descriptions and ratings are sample educational data.
