from flask import Flask, render_template, request

app = Flask(__name__)

BOOKS = [
    {"title": "The Alchemist", "author": "Paulo Coelho", "genre": "Adventure", "level": "Easy", "mood": "Inspiring", "rating": 4.8, "year": 1988, "description": "A shepherd follows his dream and discovers the meaning of his journey."},
    {"title": "Wings of Fire", "author": "A. P. J. Abdul Kalam", "genre": "Biography", "level": "Easy", "mood": "Inspiring", "rating": 4.9, "year": 1999, "description": "An inspiring account of a scientist and former President of India."},
    {"title": "Harry Potter and the Philosopher's Stone", "author": "J. K. Rowling", "genre": "Fantasy", "level": "Medium", "mood": "Magical", "rating": 4.7, "year": 1997, "description": "A young boy discovers that he belongs to a world of magic."},
    {"title": "The Blue Umbrella", "author": "Ruskin Bond", "genre": "Fiction", "level": "Easy", "mood": "Peaceful", "rating": 4.5, "year": 1980, "description": "A gentle story about a girl and her beautiful blue umbrella."},
    {"title": "Atomic Habits", "author": "James Clear", "genre": "Self-help", "level": "Medium", "mood": "Motivating", "rating": 4.8, "year": 2018, "description": "Learn how small daily habits can lead to meaningful change."},
    {"title": "Malgudi Days", "author": "R. K. Narayan", "genre": "Fiction", "level": "Easy", "mood": "Peaceful", "rating": 4.6, "year": 1943, "description": "Memorable stories about ordinary people in the town of Malgudi."},
    {"title": "The Diary of a Young Girl", "author": "Anne Frank", "genre": "Biography", "level": "Medium", "mood": "Thoughtful", "rating": 4.7, "year": 1947, "description": "A moving diary that shares the thoughts and hopes of a young writer."},
    {"title": "The Hobbit", "author": "J. R. R. Tolkien", "genre": "Fantasy", "level": "Medium", "mood": "Magical", "rating": 4.8, "year": 1937, "description": "Bilbo Baggins begins an unexpected adventure."}
]

@app.route("/", methods=["GET", "POST"])
def home():
    search = request.form.get("search", "").strip().lower()
    genre = request.form.get("genre", "All")
    mood = request.form.get("mood", "All")
    level = request.form.get("level", "All")

    results = BOOKS[:]
    if search:
        results = [b for b in results if search in b["title"].lower() or search in b["author"].lower()]
    if genre != "All":
        results = [b for b in results if b["genre"] == genre]
    if mood != "All":
        results = [b for b in results if b["mood"] == mood]
    if level != "All":
        results = [b for b in results if b["level"] == level]

    results.sort(key=lambda book: book["rating"], reverse=True)
    return render_template(
        "index.html", books=results, search=search, genre=genre, mood=mood,
        level=level, genres=sorted({b["genre"] for b in BOOKS}),
        moods=sorted({b["mood"] for b in BOOKS})
    )

@app.route("/about")
def about():
    return render_template("about.html", total=len(BOOKS))

if __name__ == "__main__":
    app.run(debug=True)
