# ReadQuest — Presentation Notes

## Introduction
Good morning. My project is ReadQuest, a Library Book Recommendation System developed using Python and Flask. It helps readers discover books by searching and choosing their preferences.

## Problem statement
Readers may find it difficult to choose a book from a large collection. This project makes discovery easier with simple filters.

## Objectives
1. Display a collection of books.
2. Search by title or author.
3. Filter by genre, mood and reading level.
4. Show higher-rated matching books first.

## Working process
Book details are stored in a Python list of dictionaries. Flask receives the form selections. Python filters the list and sorts the results by rating. Flask then sends the results to the HTML page.

## Viva questions
1. What is Flask? A lightweight web framework for Python.
2. What is a dictionary? A collection of key-value pairs.
3. What is a list? An ordered collection of items.
4. What is filtering? Selecting items that match given conditions.
5. Why use `sorted()`? To arrange books by rating.
6. What is HTML? The language used to structure web pages.
7. What is CSS? The language used to style web pages.
8. What is a route? A URL connected to a Python function.
9. What is a rule-based recommendation? A recommendation made using fixed conditions or rules.
10. Does this project use machine learning? No. It uses simple filters and sample ratings.
